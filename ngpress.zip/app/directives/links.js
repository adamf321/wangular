(function ()
{
    angular.module('ngpress').directive('a', ['$location', function ($location)
    {
        var link = function(scope, element, attrs)
        {
            var parser = document.createElement('a');

            parser.href = attrs.href;

            if( parser.hostname === $location.host() && parser.pathname.indexOf('/wp-admin') !== 0 )
            {
                element.on('click', function(e)
                {
                    var posts = new wp.api.collections.Posts();

                    posts.fetch().done( function() {
                        posts.each( function( post ) {
                            // post.attributes contain the attributes of the post
                            console.log( post.attributes );
                        });
                    });

                    //$location.url('/page1');

                    //alert('gi');
                    //e.preventDefault();
                });
            }
        };

        return {
            link: link,
            restrict: 'E'
        };
    }]);
}());