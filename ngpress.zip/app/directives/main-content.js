(function ()
{
    angular.module('ngpress').directive('ngpMainContent',
        ['$location', function ($location)
        {
            var link = function(scope, element, attrs)
            {
                scope.$watch(
                    $location.path(),
                    function( value )
                    {
                        //alert( $location.path() );
                    }
                );
            };

            return {
                link: link,
                restrict: 'AE'
            };
        }]);
}());