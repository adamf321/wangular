var angular = require('../bower_components/angular');

var app = require('./app');

//var bulk = require('bulk-require');
//console.log('blah');
//var sections = bulk(__dirname, [ './directives/*.js' ]);
//console.log(sections);

require('./directives/links');
require('./directives/main-content');