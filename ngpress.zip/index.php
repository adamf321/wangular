<?php get_header(); ?>

<div id="content" class="site-content" ngp-main-content>

</div><!-- .site-content -->

<?php get_footer(); ?>