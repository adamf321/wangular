<?php

define( 'NGP_TEXT_DOMAIN', 'ngpress' );

include_once( 'modules/Main.php' );

\ngPress\Modules\Main::init();